// model/TipCheltuiala.java
package ro.hoa.model;

public enum TipCheltuiala {
    PERSOANA,       // Se împarte la numărul total de persoane
    SUPRAFATA,      // Se împarte la suprafața totală
    APARTAMENT,     // Se împarte egal la fiecare apartament
}